result.Entity = require('./Entity');
result.Person = require('./Person');
result.Dog = require('./Dog');
result.Student = require('./Student');