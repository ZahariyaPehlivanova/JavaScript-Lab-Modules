let person = require('./Person');
result.Person = person;